
module.exports.post = function(req,res){
    res.end('<h1>user Post</h1>');


}
// we have to access this controller function inside the router file